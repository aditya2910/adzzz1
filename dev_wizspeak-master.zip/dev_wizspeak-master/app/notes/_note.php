<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * #sand
 * roles
 *  superadmin
 *  admin
 *  member
 *  follower
 * 
 *permissions
 *  Read_post
 *  Write_post
 *  Like_post
 *  Share_post
 *  Comment_post
 *  Edit_post
 * 
 *  Invite_to_group
 *  Group_join_request
 *  block_user
 *  edit_group_details
 *  edit_group_title
 *  
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */

