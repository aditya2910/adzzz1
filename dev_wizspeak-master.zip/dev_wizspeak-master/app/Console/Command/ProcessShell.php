<?php

class ProcessShell extends AppShell {
    public function main() {
        $this->out('Hello world.');
    }
}