<?php /* Smarty version Smarty 3.1.4, created on 2015-09-05 07:02:57
         compiled from "/home/destina1/public_html/absoluto/tec1/app/webroot/chat/admin/layout/pages_footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:175914541755eacbe1404368-86189489%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dc8d556c8e0b681361ff6a980c962ed75fa31a67' => 
    array (
      0 => '/home/destina1/public_html/absoluto/tec1/app/webroot/chat/admin/layout/pages_footer.tpl',
      1 => 1330802506,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '175914541755eacbe1404368-86189489',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty 3.1.4',
  'unifunc' => 'content_55eacbe140da7',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55eacbe140da7')) {function content_55eacbe140da7($_smarty_tpl) {?>		</div>
		<div class="clear"></div>
		<div style="height: 40px;"></div>
		<div class="push"></div>
	</div>
</div>
<div class="footer">
	<div class="footercontent">
		<div style="float: left; padding-top:6px;">
			<a href="http://www.arrowchat.com" target="_blank">ArrowChat Website</a> &bull; <a href="http://www.arrowchat.com/support/" target="_blank">Support</a>
		</div>
		<div style="float: right; padding-top:6px;">
			<i>Version <?php echo @ARROWCHAT_VERSION;?>
</i>
		</div>
	</div>
</div>
</body>
</html><?php }} ?>