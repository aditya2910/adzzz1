<?php
App::uses('GroupGroupConnectsController', 'Controller');

/**
 * GroupGroupConnectsController Test Case
 *
 */
class GroupGroupConnectsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.group_group_connect',
		'app.requestby_user',
		'app.actionby_user'
	);

}
