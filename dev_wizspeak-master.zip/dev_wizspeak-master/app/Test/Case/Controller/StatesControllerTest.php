<?php
App::uses('StatesController', 'Controller');

/**
 * StatesController Test Case
 *
 */
class StatesControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.state',
		'app.country',
		'app.city'
	);

}
