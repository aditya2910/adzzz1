<?php
App::uses('VerticalsController', 'Controller');

/**
 * VerticalsController Test Case
 *
 */
class VerticalsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.vertical',
		'app.category'
	);

}
