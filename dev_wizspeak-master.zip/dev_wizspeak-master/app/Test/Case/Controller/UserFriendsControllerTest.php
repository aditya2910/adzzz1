<?php
App::uses('UserFriendsController', 'Controller');

/**
 * UserFriendsController Test Case
 *
 */
class UserFriendsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.user_friend'
	);

}
