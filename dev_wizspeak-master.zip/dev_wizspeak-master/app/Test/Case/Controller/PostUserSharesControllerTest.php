<?php
App::uses('PostUserSharesController', 'Controller');

/**
 * PostUserSharesController Test Case
 *
 */
class PostUserSharesControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.post_user_share',
		'app.shareby',
		'app.shareto'
	);

}
