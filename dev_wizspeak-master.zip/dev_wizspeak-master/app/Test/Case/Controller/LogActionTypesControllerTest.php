<?php
App::uses('LogActionTypesController', 'Controller');

/**
 * LogActionTypesController Test Case
 *
 */
class LogActionTypesControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.log_action_type'
	);

}
